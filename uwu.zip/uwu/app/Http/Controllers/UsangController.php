<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsangController extends Controller
{
    // ditambahkan ini sedikit
    public function index(){
        echo "pesan dari index milik usang controller";
    }

    public function godog(){
        echo "pohong lebih jos";
    }

    
}
